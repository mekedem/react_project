export const showMemoDescription = ({memoId} = {}) => ({
    type: 'SHOW_MEMO_DESCRIPTION',
    memoId
  });