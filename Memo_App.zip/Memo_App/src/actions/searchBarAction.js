export const showSearch = () => ({
  type: 'SHOW_SEARCH'
});

export const hideSearch = () => ({
  type: 'HIDE_SEARCH'
});
